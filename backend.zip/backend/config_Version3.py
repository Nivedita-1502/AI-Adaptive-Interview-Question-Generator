import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    """Configuration settings for the application"""
    
    # Flask Settings
    DEBUG = os.getenv('DEBUG', True)
    SECRET_KEY = os.getenv('SECRET_KEY', 'dev-secret-key-2026')
    
    # Data Settings
    DATASET_PATH = os.getenv('DATASET_PATH', 'data/interview_questions_cleaned.xlsx')
    TRAINING_DATA_PATH = os.getenv('TRAINING_DATA_PATH', 'data/training_pairs.csv')
    
    # Model Settings
    BASE_MODEL = 'all-MiniLM-L6-v2'  # Base pre-trained model
    FINETUNED_MODEL_PATH = os.getenv('FINETUNED_MODEL_PATH', 'models/fine_tuned_model')
    EMBEDDING_MODEL = FINETUNED_MODEL_PATH if os.path.exists(FINETUNED_MODEL_PATH) else BASE_MODEL
    
    # Similarity Thresholds
    SIMILARITY_THRESHOLD_CORRECT = 0.85
    SIMILARITY_THRESHOLD_PARTIAL = 0.60
    
    # Quiz Settings
    TOTAL_QUESTIONS_PER_QUIZ = 3
    SUPPORTED_SUBJECTS = ['dbms', 'dsa', 'os']
    SUPPORTED_DIFFICULTIES = ['easy', 'medium', 'hard']
    
    # Training Settings
    TRAINING_BATCH_SIZE = 16
    TRAINING_EPOCHS = 4
    WARMUP_STEPS = 500
    MODEL_SAVE_PATH = 'models/fine_tuned_model'