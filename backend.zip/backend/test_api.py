import requests
import json

BASE_URL = "http://127.0.0.1:5000/api"

def print_section(title):
    print("\n" + "="*60)
    print(title)
    print("="*60)

def test_health():
    print_section("1. Testing Health API")

    url = f"{BASE_URL}/health"
    r = requests.get(url)

    print("Status:", r.status_code)
    print(json.dumps(r.json(), indent=2))


def test_subjects():
    print_section("2. Testing Subjects API")

    url = f"{BASE_URL}/questions/subjects"
    r = requests.get(url)

    print("Status:", r.status_code)
    print(json.dumps(r.json(), indent=2))

    return r.json().get("subjects", [])


def test_get_question():
    print_section("3. Testing Question API")

    url = f"{BASE_URL}/questions/get-question"

    data = {
        "subject": "dbms",
        "difficulty": "easy"
    }

    r = requests.post(url, json=data)

    print("Status:", r.status_code)
    response = r.json()
    print(json.dumps(response, indent=2))

    if response.get("success"):
        ideal = response.get("ideal_answer")
        question = response.get("data", {}).get("question")
        return question, ideal

    return None, None


def test_evaluation(ideal_answer):
    print_section("4. Testing Evaluation API")

    url = f"{BASE_URL}/evaluation/submit-answer"

    data = {
        "user_answer": "Normalization removes redundancy in database tables.",
        "ideal_answer": ideal_answer
    }

    r = requests.post(url, json=data)

    print("Status:", r.status_code)
    response = r.json()
    print(json.dumps(response, indent=2))

    if response.get("success"):
        return response["evaluation"]["similarity_score"]

    return None


def test_next_difficulty(score):
    print_section("5. Testing Difficulty Adaptation API")

    url = f"{BASE_URL}/evaluation/get-next-difficulty"

    data = {
        "current_difficulty": "easy",
        "similarity_score": score
    }

    r = requests.post(url, json=data)

    print("Status:", r.status_code)
    print(json.dumps(r.json(), indent=2))


def main():

    test_health()

    subjects = test_subjects()

    question, ideal = test_get_question()

    if ideal:
        score = test_evaluation(ideal)

        if score is not None:
            test_next_difficulty(score)


if __name__ == "__main__":
    main()