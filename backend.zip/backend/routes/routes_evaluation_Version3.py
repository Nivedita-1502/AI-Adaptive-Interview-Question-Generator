"""
Flask routes for answer evaluation endpoints.
Uses fine-tuned Sentence Transformers for similarity evaluation.
"""

from flask import Blueprint, request, jsonify
from models.models_answer_evaluator_Version3 import AnswerEvaluator
from models.models_question_model_Version3 import QuestionDataset
from config_Version3 import Config
import logging

logger = logging.getLogger(__name__)

evaluation_bp = Blueprint('evaluation', __name__, url_prefix='/api/evaluation')

# Initialize evaluator and dataset
try:
    evaluator = AnswerEvaluator()
    dataset = QuestionDataset()
    logger.info("✓ Evaluator and dataset initialized successfully")
except Exception as e:
    logger.error(f"Error initializing: {e}")
    evaluator = None
    dataset = None

@evaluation_bp.route('/submit-answer', methods=['POST'])
def submit_answer():
    """
    Evaluate user's answer using fine-tuned Sentence Transformer.
    
    Request JSON:
        - user_answer: str
        - ideal_answer: str
    
    Response:
        - similarity_score: float (0-1)
        - classification: str (correct, partial, incorrect)
        - points: float (0, 0.5, or 1)
        - feedback: str
        - model_used: str
    """
    try:
        if evaluator is None:
            return jsonify({
                'success': False,
                'message': 'Evaluator not initialized'
            }), 500
        
        data = request.get_json()
        user_answer = data.get('user_answer', '').strip()
        ideal_answer = data.get('ideal_answer', '').strip()
        
        if not user_answer or not ideal_answer:
            return jsonify({
                'success': False,
                'message': 'User answer and ideal answer are required'
            }), 400
        
        logger.info(f"Evaluating answer (length: {len(user_answer)} chars)")
        
        # Evaluate the answer
        evaluation = evaluator.evaluate_answer(user_answer, ideal_answer)
        
        logger.info(f"  Classification: {evaluation['classification']}")
        logger.info(f"  Similarity: {evaluation['similarity_score']}")
        
        return jsonify({
            'success': True,
            'evaluation': evaluation
        }), 200
    
    except Exception as e:
        logger.error(f"Error in submit_answer: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500

@evaluation_bp.route('/batch-evaluate', methods=['POST'])
def batch_evaluate():
    """
    Evaluate multiple answers at once (more efficient).
    
    Request JSON:
        - answers: list of dicts with user_answer and ideal_answer
    
    Response:
        - evaluations: list of evaluation results
    """
    try:
        if evaluator is None:
            return jsonify({
                'success': False,
                'message': 'Evaluator not initialized'
            }), 500
        
        data = request.get_json()
        answers = data.get('answers', [])
        
        if not answers:
            return jsonify({
                'success': False,
                'message': 'Answers list is required'
            }), 400
        
        user_answers = [ans.get('user_answer', '').strip() for ans in answers]
        ideal_answers = [ans.get('ideal_answer', '').strip() for ans in answers]
        
        logger.info(f"Batch evaluating {len(answers)} answers")
        
        # Batch evaluate
        evaluations = evaluator.evaluate_batch(user_answers, ideal_answers)
        
        return jsonify({
            'success': True,
            'evaluations': evaluations
        }), 200
    
    except Exception as e:
        logger.error(f"Error in batch_evaluate: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500

@evaluation_bp.route('/get-next-difficulty', methods=['POST'])
def get_next_difficulty():
    """
    Get adaptively determined next difficulty.
    
    Request JSON:
        - current_difficulty: str
        - similarity_score: float
    
    Response:
        - next_difficulty: str
    """
    try:
        if dataset is None:
            return jsonify({'success': False, 'message': 'Dataset not loaded'}), 500
        
        data = request.get_json()
        current_difficulty = data.get('current_difficulty', 'easy').lower()
        similarity_score = data.get('similarity_score', 0)
        
        next_difficulty = dataset.get_next_difficulty(current_difficulty, similarity_score)
        
        logger.info(f"Difficulty progression: {current_difficulty} -> {next_difficulty}")
        
        return jsonify({
            'success': True,
            'next_difficulty': next_difficulty
        }), 200
    
    except Exception as e:
        logger.error(f"Error in get_next_difficulty: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500

@evaluation_bp.route('/calculate-stats', methods=['POST'])
def calculate_stats():
    """
    Calculate quiz statistics after quiz completion.
    
    Request JSON:
        - results: list of evaluation results
    
    Response:
        - stats: dict with accuracy, counts, etc.
    """
    try:
        data = request.get_json()
        results = data.get('results', [])
        
        if not results:
            return jsonify({
                'success': False,
                'message': 'Results are required'
            }), 400
        
        total = len(results)
        correct = sum(1 for r in results if r['classification'] == 'correct')
        partial = sum(1 for r in results if r['classification'] == 'partial')
        incorrect = sum(1 for r in results if r['classification'] == 'incorrect')
        
        # Calculate accuracy: correct answers + 50% of partial answers
        accuracy = (correct + partial * 0.5) / total if total > 0 else 0
        score = correct + partial * 0.5
        
        stats = {
            'total_questions': total,
            'correct_answers': correct,
            'partial_answers': partial,
            'incorrect_answers': incorrect,
            'accuracy_percentage': round(accuracy * 100, 2),
            'score': f"{score}/{total}",
            'passed': accuracy >= 0.70  # 70% threshold to pass
        }
        
        logger.info(f"Quiz completed: {stats['score']} ({stats['accuracy_percentage']}%)")
        
        return jsonify({
            'success': True,
            'stats': stats
        }), 200
    
    except Exception as e:
        logger.error(f"Error in calculate_stats: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500

@evaluation_bp.route('/model-info', methods=['GET'])
def model_info():
    """Get information about the current evaluation model"""
    try:
        if evaluator is None:
            return jsonify({'success': False, 'message': 'Evaluator not initialized'}), 500
        
        info = evaluator.get_model_info()
        
        return jsonify({
            'success': True,
            'model_info': info
        }), 200
    except Exception as e:
        logger.error(f"Error in model_info: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500

@evaluation_bp.route('/health', methods=['GET'])
def evaluation_health():
    """Health check for evaluation service"""
    try:
        evaluator_ready = evaluator is not None
        model_info = evaluator.get_model_info() if evaluator_ready else {}
        
        return jsonify({
            'success': True,
            'service': 'evaluation',
            'evaluator_ready': evaluator_ready,
            'model_info': model_info
        }), 200
    except Exception as e:
        logger.error(f"Error in evaluation_health: {e}")
        return jsonify({
            'success': False,
            'service': 'evaluation',
            'error': str(e)
        }), 500