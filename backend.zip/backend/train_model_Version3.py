"""
Fine-tune Sentence Transformers on interview QA pairs.
Trains the model to better evaluate answer similarity.
"""

from sentence_transformers import SentenceTransformer, InputExample, losses, models
from sentence_transformers.evaluation import EmbeddingSimilarityEvaluator
from torch.utils.data import DataLoader
import pandas as pd
import numpy as np
import os
from config_Version3 import Config
from data_preparation_Version3 import prepare_training_data
import logging

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def load_training_data(csv_path):
    """Load training data from CSV"""
    print(f"\nLoading training data from {csv_path}...")
    df = pd.read_csv(csv_path)
    
    # Create InputExample objects
    train_samples = [
        InputExample(
            texts=[str(row['sentence1']).strip(), str(row['sentence2']).strip()],
            label=float(row['label'])
        )
        for idx, row in df.iterrows()
    ]
    
    print(f"✓ Loaded {len(train_samples)} training samples")
    return train_samples

def split_data(samples, train_ratio=0.85):
    """Split data into train and validation sets"""
    split_idx = int(len(samples) * train_ratio)
    return samples[:split_idx], samples[split_idx:]

def fine_tune_model():
    """Fine-tune Sentence Transformer on interview QA data"""
    
    print("="*70)
    print("FINE-TUNING SENTENCE TRANSFORMER FOR INTERVIEW ANSWER EVALUATION")
    print("="*70)
    
    # Step 1: Prepare training data
    if not os.path.exists(Config.TRAINING_DATA_PATH):
        print("\n[Step 1] Preparing training data...")
        prepare_training_data()
    else:
        print(f"\n[Step 1] Training data already exists: {Config.TRAINING_DATA_PATH}")
    
    # Step 2: Load training data
    print("\n[Step 2] Loading training data...")
    samples = load_training_data(Config.TRAINING_DATA_PATH)
    train_samples, val_samples = split_data(samples, train_ratio=0.85)
    print(f"  Training samples: {len(train_samples)}")
    print(f"  Validation samples: {len(val_samples)}")
    
    # Step 3: Load pre-trained model
    print(f"\n[Step 3] Loading base model: {Config.BASE_MODEL}...")
    model = SentenceTransformer(Config.BASE_MODEL)
    print("✓ Model loaded successfully")
    
    # Step 4: Create DataLoader
    print("\n[Step 4] Creating DataLoader...")
    train_dataloader = DataLoader(
        train_samples,
        shuffle=True,
        batch_size=Config.TRAINING_BATCH_SIZE
    )
    print(f"✓ DataLoader created with batch size {Config.TRAINING_BATCH_SIZE}")
    
    # Step 5: Define loss function
    print("\n[Step 5] Setting up loss function...")
    train_loss = losses.CosineSimilarityLoss(model)
    print("✓ Using CosineSimilarityLoss")
    
    # Step 6: Optional - Create evaluator
    print("\n[Step 6] Setting up evaluator...")
    if val_samples:
        evaluator = EmbeddingSimilarityEvaluator.from_input_examples(
            val_samples,
            name='val'
        )
        print(f"✓ Evaluator ready with {len(val_samples)} validation samples")
    else:
        evaluator = None
        print("⚠ No validation evaluator (limited validation samples)")
    
    # Step 7: Fine-tune the model
    print("\n[Step 7] Starting fine-tuning...")
    print(f"  Epochs: {Config.TRAINING_EPOCHS}")
    print(f"  Warmup steps: {Config.WARMUP_STEPS}")
    print(f"  Batch size: {Config.TRAINING_BATCH_SIZE}")
    print("-" * 70)
    
    # Create model save directory
    os.makedirs(Config.MODEL_SAVE_PATH, exist_ok=True)
    
    # Fine-tune
    model.fit(
        train_objectives=[(train_dataloader, train_loss)],
        evaluator=evaluator,
        epochs=Config.TRAINING_EPOCHS,
        evaluation_steps=max(1, len(train_dataloader) // 2),
        warmup_steps=Config.WARMUP_STEPS,
        output_path=Config.MODEL_SAVE_PATH,
        save_best_model=True,
        show_progress_bar=True,
    )
    
    print("-" * 70)
    print("\n[Step 8] Training complete!")
    print(f"✓ Model saved to: {Config.MODEL_SAVE_PATH}")
    
    # Step 9: Test the fine-tuned model
    print("\n[Step 9] Testing fine-tuned model...")
    test_sentences = [
        ("Database transactions", "ACID properties ensure atomic transactions"),
        ("Binary search", "Tree data structure for fast searching"),
        ("Virtual memory", "Page replacement algorithms in OS"),
        ("Stack", "Queue data structure"),  # Should have low similarity
    ]
    
    fine_tuned_model = SentenceTransformer(Config.MODEL_SAVE_PATH)
    embeddings = fine_tuned_model.encode([s[0] for s in test_sentences], convert_to_tensor=True)
    
    print("\nSample Predictions:")
    print("-" * 70)
    from sentence_transformers import util
    for i, (sent1, sent2) in enumerate(test_sentences):
        emb1 = fine_tuned_model.encode(sent1, convert_to_tensor=True)
        emb2 = fine_tuned_model.encode(sent2, convert_to_tensor=True)
        similarity = util.pytorch_cos_sim(emb1, emb2)[0][0].item()
        print(f"{i+1}. '{sent1}' <-> '{sent2}'")
        print(f"   Similarity: {similarity:.4f}\n")
    
    print("="*70)
    print("FINE-TUNING COMPLETE! Model is ready for evaluation.")
    print("="*70)

if __name__ == '__main__':
    fine_tune_model()