"""
Prepare training data for fine-tuning sentence transformers.
Creates pairs of (user_answer, ideal_answer) with similarity labels.
"""

import pandas as pd
import numpy as np
from sentence_transformers import SentenceTransformer, util
import os
import json
from config_Version3 import Config

def prepare_training_data():
    """
    Create training pairs from the interview questions dataset.
    This creates synthetic training data from ideal answers and keywords.
    """
    
    print("="*60)
    print("PREPARING TRAINING DATA FOR FINE-TUNING")
    print("="*60)
    
    # Load the main dataset
    try:
        df = pd.read_excel(Config.DATASET_PATH)
        df.columns = df.columns.str.lower().str.strip()
        print(f"✓ Loaded {len(df)} questions from dataset")
    except Exception as e:
        print(f"✗ Error loading dataset: {e}")
        return False
    
    training_pairs = []
    
    # Create training pairs from dataset
    for idx, row in df.iterrows():
        ideal_answer = str(row['ideal_answer']).strip()
        keywords = str(row['keywords']).strip()
        question = str(row['question_text']).strip()
        
        if not ideal_answer:
            continue
        
        # Pair 1: Ideal answer with itself (similarity = 1.0)
        training_pairs.append({
            'sentence1': ideal_answer,
            'sentence2': ideal_answer,
            'label': 1.0
        })
        
        # Pair 2: Ideal answer with keywords (high similarity = 0.8)
        if keywords:
            training_pairs.append({
                'sentence1': ideal_answer,
                'sentence2': keywords,
                'label': 0.8
            })
        
        # Pair 3: Question with ideal answer (medium similarity = 0.6)
        if question:
            training_pairs.append({
                'sentence1': question,
                'sentence2': ideal_answer,
                'label': 0.6
            })
        
        # Pair 4: Create synthetic wrong answers with low similarity
        # Mix keywords from different questions for negative examples
        if idx + 1 < len(df):
            next_row = df.iloc[idx + 1]
            next_keywords = str(next_row['keywords']).strip()
            
            if next_keywords:
                training_pairs.append({
                    'sentence1': ideal_answer,
                    'sentence2': next_keywords,
                    'label': 0.2  # Low similarity
                })
    
    # Create DataFrame and save
    training_df = pd.DataFrame(training_pairs)
    
    # Shuffle
    training_df = training_df.sample(frac=1).reset_index(drop=True)
    
    # Create data directory
    os.makedirs('data', exist_ok=True)
    
    # Save training data
    training_df.to_csv(Config.TRAINING_DATA_PATH, index=False)
    print(f"✓ Created {len(training_df)} training pairs")
    print(f"✓ Training data saved to: {Config.TRAINING_DATA_PATH}")
    
    # Print statistics
    print("\nTraining Data Statistics:")
    print(f"  Total pairs: {len(training_df)}")
    print(f"  Perfect matches (1.0): {len(training_df[training_df['label'] == 1.0])}")
    print(f"  High similarity (0.8): {len(training_df[training_df['label'] == 0.8])}")
    print(f"  Medium similarity (0.6): {len(training_df[training_df['label'] == 0.6])}")
    print(f"  Low similarity (0.2): {len(training_df[training_df['label'] == 0.2])}")
    
    return True

if __name__ == '__main__':
    prepare_training_data()